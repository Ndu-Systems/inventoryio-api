
ALTER TABLE `company` ADD `Shop` VARCHAR(50) NULL AFTER `Website`, ADD `Handler` INT(1) NULL AFTER `Shop`;
