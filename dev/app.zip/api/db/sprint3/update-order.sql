ALTER TABLE `orders` ADD `Status` VARCHAR(50) NULL AFTER `ModifyUserId`;
