<?php
include_once '../../config/Database.php';
include_once '../../models/Users.php';
include_once '../../models/Company.php';

$data = json_decode(file_get_contents("php://input"));

// create user data only
$Email = $data->email;
$Password = $data->password; 

//connect to db
$database = new Database();
$db = $database->connect();

//Instantiate user object
$user = new Users($db);
$company = new Company($db);

$result = $user->getUserByEmailandPassword($Email,$Password);
$userCompany = $company->getById($result["CompanyId"] );
$result["Company"] = $userCompany;
echo json_encode($result);





