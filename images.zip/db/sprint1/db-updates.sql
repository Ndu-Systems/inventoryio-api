ALTER TABLE `users` ADD `RoleId` INT(10) NULL AFTER `CompanyId`;


